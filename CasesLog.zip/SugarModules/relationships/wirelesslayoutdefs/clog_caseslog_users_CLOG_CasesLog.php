<?php
 // created: 2017-01-06 17:40:09
$layout_defs["CLOG_CasesLog"]["subpanel_setup"]['clog_caseslog_users'] = array (
  'order' => 100,
  'module' => 'Users',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_CLOG_CASESLOG_USERS_FROM_USERS_TITLE',
  'get_subpanel_data' => 'clog_caseslog_users',
);
