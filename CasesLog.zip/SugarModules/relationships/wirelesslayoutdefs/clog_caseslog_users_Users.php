<?php
 // created: 2017-01-06 18:53:25
$layout_defs["Users"]["subpanel_setup"]['clog_caseslog_users'] = array (
  'order' => 100,
  'module' => 'CLOG_CasesLog',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_CLOG_CASESLOG_USERS_FROM_CLOG_CASESLOG_TITLE',
  'get_subpanel_data' => 'clog_caseslog_users',
);
