<?php
// created: 2017-01-06 18:53:24
$dictionary["User"]["fields"]["clog_caseslog_users"] = array (
  'name' => 'clog_caseslog_users',
  'type' => 'link',
  'relationship' => 'clog_caseslog_users',
  'source' => 'non-db',
  'module' => 'CLOG_CasesLog',
  'bean_name' => 'CLOG_CasesLog',
  'side' => 'right',
  'vname' => 'LBL_CLOG_CASESLOG_USERS_FROM_CLOG_CASESLOG_TITLE',
);
