<?php
// created: 2017-01-06 18:53:24
$dictionary["Case"]["fields"]["clog_caseslog_cases"] = array (
  'name' => 'clog_caseslog_cases',
  'type' => 'link',
  'relationship' => 'clog_caseslog_cases',
  'source' => 'non-db',
  'module' => 'CLOG_CasesLog',
  'bean_name' => 'CLOG_CasesLog',
  'side' => 'right',
  'vname' => 'LBL_CLOG_CASESLOG_CASES_FROM_CLOG_CASESLOG_TITLE',
);
