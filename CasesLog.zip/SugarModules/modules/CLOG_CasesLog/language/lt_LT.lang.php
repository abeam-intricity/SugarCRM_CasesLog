<?php
/*********************************************************************************
 * By installing or using this file, you are confirming on behalf of the entity
 * subscribed to the SugarCRM Inc. product ("Company") that Company is bound by
 * the SugarCRM Inc. Master Subscription Agreement (“MSA”), which is viewable at:
 * http://www.sugarcrm.com/master-subscription-agreement
 *
 * If Company is not bound by the MSA, then by installing or using this file
 * you are agreeing unconditionally that Company will be bound by the MSA and
 * certifying that you have authority to bind Company accordingly.
 *
 * Copyright (C) 2004-2013 SugarCRM Inc.  All rights reserved.
 ********************************************************************************/

$mod_strings = array (
  'LBL_TEAM' => 'Komandos',
  'LBL_TEAMS' => 'Komandos',
  'LBL_TEAM_ID' => 'Komandos Id',
  'LBL_ASSIGNED_TO_ID' => 'Atsakingo Id',
  'LBL_ASSIGNED_TO_NAME' => 'Atsakingas',
  'LBL_CREATED' => 'Sukūrė',
  'LBL_CREATED_ID' => 'Kūrėjo Id',
  'LBL_CREATED_USER' => 'Sukūrė',
  'LBL_DATE_ENTERED' => 'Sukurta',
  'LBL_DATE_MODIFIED' => 'Redaguota',
  'LBL_DELETED' => 'Ištrintas',
  'LBL_DESCRIPTION' => 'Aprašymas',
  'LBL_EDIT_BUTTON' => 'Redaguoti',
  'LBL_ID' => 'ID',
  'LBL_LIST_NAME' => 'Pavadinimas',
  'LBL_MODIFIED' => 'Redagavo',
  'LBL_MODIFIED_ID' => 'Redaguotojo Id',
  'LBL_MODIFIED_NAME' => 'Redaguotojo vardas',
  'LBL_MODIFIED_USER' => 'Redagavo',
  'LBL_NAME' => 'Pavadinimas',
  'LBL_REMOVE' => 'Išimti',
  'LBL_LIST_FORM_TITLE' => 'Cases Log Sąrašas',
  'LBL_MODULE_NAME' => 'Cases Log',
  'LBL_MODULE_TITLE' => 'Cases Log',
  'LBL_HOMEPAGE_TITLE' => 'Mano Cases Log',
  'LNK_NEW_RECORD' => 'Sukurti Cases Log',
  'LNK_LIST' => 'View Cases Log',
  'LNK_IMPORT_CLOG_CASESLOG' => 'Import Cases Log',
  'LBL_SEARCH_FORM_TITLE' => 'Paieška Cases Log',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Rodyti istoriją',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Priminimai',
  'LBL_CLOG_CASESLOG_SUBPANEL_TITLE' => 'Cases Log',
  'LBL_NEW_FORM_TITLE' => 'Naujas Cases Log',
  'LBL_LOG_DATE' => 'Log Date',
);