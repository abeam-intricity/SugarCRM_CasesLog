# SugarCRM_CasesLog
Logging which records were modified by a user and when.
